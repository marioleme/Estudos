// Criando o elemento canvas do HTML5
var canvas = document.createElement("canvas"); //A tag <canvas> é usado para desenhar gráficos, normalmente através de JavaScript.
var ctx = canvas.getContext("2d"); //retorna um objeto com métodos e propriedades para desenhar na tela.
canvas.width = 512;
canvas.height = 480;
document.body.appendChild(canvas);

// Background do jogo
var bgReady = false;
var bgImage = new Image();
bgImage.onload = function () {
	bgReady = true;
};
bgImage.src = "background.png";

// imagem do lixo
var lixoReady = false;
var lixoImage = new Image();
lixoImage.onload = function () {
	lixoReady = true;
};
lixoImage.src = "lixo.png";

// imagem da lixeira
var lixeiraReady = false;
var lixeiraImage = new Image();
lixeiraImage.onload = function () {
	lixeiraReady = true;
};
lixeiraImage.src = "lixeira.png";

// Objetos do jogo
var lixo = { speed: 1 }; /* pixels por segundo */ 
var lixeira = {};
var lixosRecolhidos = 0;

// Controlando pelo teclado
var keysDown = {};

addEventListener("keydown", function (e) {
	keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) {
	delete keysDown[e.keyCode];
}, false);

// Resetando o jogo
var reset = function () {
	lixo.x = canvas.width / 2;
	lixo.y = canvas.height / 2;

    lixeira.x = 32 + (Math.random() * (canvas.width - 64));
	lixeira.y = 32 + (Math.random() * (canvas.height - 64));
};

// Controle das direções (Essa função verifica qual a tecla foi pressionada e reposiciona o lixo na tela).
var update = function () {

	if (38 in keysDown) { // para cima
		lixo.y -= lixo.speed ;
	}
	if (40 in keysDown) { // para baixo
		lixo.y += lixo.speed ;
	}
	if (37 in keysDown) { // para esquerda
		lixo.x -= lixo.speed ;
	}
	if (39 in keysDown) { // para direita
		lixo.x += lixo.speed ;
	}

	//verifica a colisão
	if (lixo.x <= (lixeira.x + 32)	&& lixeira.x <= (lixo.x + 32)	&&  lixo.y <= (lixeira.y + 32)	&& lixeira.y <= (lixo.y + 32)) {
		++lixosRecolhidos;
		reset();
	}
};

// Desenhando na tela
var render = function () {
	
	if (bgReady) {
		ctx.drawImage(bgImage, 0, 0);
	}

	if (lixoReady) {
		ctx.drawImage(lixoImage, lixo.x, lixo.y);
	}

	if (lixeiraReady) {
		ctx.drawImage(lixeiraImage, lixeira.x, lixeira.y);
	}

	// Placar
	ctx.fillStyle = "#FFF";
	ctx.font = "30px Verdana";
	ctx.textAlign = "left";
	ctx.textBaseline = "top";
	ctx.fillText("Lixos Recolhidos: " + lixosRecolhidos, 32, 32);
};

// loop do jogo
var main = function () {

	update();
	render();
};

// Inicia o jogo
reset();

setInterval(main, 1); 